package com.mywallet.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.mywallet.bean.Customer;
import com.mywallet.exception.WalletException;
import com.mywallet.service.IWalletService;
import com.mywallet.service.WalletService;

public class WalletDaoTest {
	
	IWalletService ws;

	@Before
	public void setup() {
		ws = new WalletService();
	}
	
	@After
	public void teardown() {
		ws = null;
	}
	
	@Test
	public void testCreateAccount() {
		try {
			Customer cust = new Customer();
			cust.setUserName("Khishy");
			cust.setPin(123);
			cust.setMobile("12345");
			assertNotEquals(ws.createAccount(cust),22);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testLogin() {
		try {
			assertEquals(ws.login(1, 456), true);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetBalance() {
		try {
			assertEquals(ws.showBalance(3), 1234567, 0.0);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testDepositAcc() {
		try {
			assertEquals(ws.deposit(1, 1000),true);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testWithdrawAcc() {
		try {
			assertEquals(ws.withdraw(1, 1000),true);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testTransferAcc() {
		try {
			assertEquals(ws.fundTransfer(1,2,1),true);
			assertEquals(ws.fundTransfer(2,1,1),true);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testPrintTransaction() {
		try {
			assertEquals(ws.printtransaction(1),false);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
