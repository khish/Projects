package com.mywallet.dao;

import java.util.HashMap;
import java.util.Optional;
import com.mywallet.bean.Bank;
import com.mywallet.db.WalletDB;
import com.mywallet.exception.WalletException;

public class WalletDao implements IWalletDao{

	static HashMap<Integer, Bank> bankmap = WalletDB.getAccountMap();
	Bank b = new Bank();
	String app = null;
	String sum =null;
	
	@Override
	public int createAccount(String uname, String upass) throws WalletException {
		int reqid;
		try {
			if(bankmap.size()==0) {
				reqid=1001;
				b.setAccNo(reqid);
			}
			else {
				Optional<Integer> id = bankmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				reqid = id.get()+1;
				b.setAccNo(reqid);
			}
			Bank bin = new Bank(reqid, uname, upass,0.0f, null);
			bankmap.put(b.getAccNo(),bin);
			return b.getAccNo();
		} catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
	}

	@Override
	public boolean login(int accno, String upass) throws WalletException {
		Bank bb = new Bank();
		try {
			bb = bankmap.get(accno);
			if(bb==null) {
				throw new WalletException("Invalid Account Number");
			}
			if(!bb.getPasscode().equals(upass)) {
				throw new WalletException("Incorrect Password!");
			}
			return true;
		} catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
	}

	@Override
	public float getBalance(int accno) throws WalletException {
		Bank bb = new Bank();
		try {
			bb = bankmap.get(accno);
			return bb.getBalance();
		} catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
	}

	@Override
	public float depositAcc(int accno, float input) throws WalletException {
		Bank bb = new Bank();
		try {
			bb = bankmap.get(accno);
			float sal = bb.getBalance();
			sal+=input;
			bb.setBalance(sal);
			if(bb.getTransactions()==null) {
				bb.setTransactions("\nAccount Number "+accno+" credited with "+input);
			}
			else {
				app="\nAccount Number "+accno+" credited with "+input;
				sum=bb.getTransactions()+app;
				bb.setTransactions(sum);
			}
			bankmap.put(accno, bb);
			return bb.getBalance();
		} catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
	}

	@Override
	public float withdrawAcc(int accno, float input) throws WalletException {
		Bank bb = new Bank();
		try {
			bb = bankmap.get(accno);
			float sal = bb.getBalance();
			sal-=input;
			bb.setBalance(sal);
			if(bb.getTransactions()==null) {
				bb.setTransactions("\nAccount Number "+accno+" debited with "+input);				
			}
			else {
				app="\nAccount Number "+accno+" debited with "+input;
				sum=bb.getTransactions()+app;
				bb.setTransactions(sum);
			}
			bankmap.put(accno, bb);
			return bb.getBalance();
		} catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
	}

	@Override
	public boolean transferAcc(int accno, int accno2, float input) throws WalletException {
		Bank bb = new Bank();
		Bank bb1 = new Bank();
		try {
			if(bankmap.get(accno2)==null)
			{
				throw new WalletException("Invalid Destination Account number");
			}
			bb = bankmap.get(accno);
			float sal = bb.getBalance();
			System.out.println("Initial balance in :"+accno+" is: "+sal);
			sal-=input;
			bb.setBalance(sal);
			if(bb.getTransactions()==null) {
				bb.setTransactions("\nFund Transfer: To Account Number: "+accno2+" Amount: "+input);	
			}
			else {
				app="\nFund Transfer: To Account Number: "+accno2+"Amount: "+input;
				sum=bb.getTransactions()+app;
				bb.setTransactions(sum);
			}
			bankmap.put(accno, bb);
			System.out.println("New balance in :"+accno+" is: "+bb.getBalance());
			bb1 = bankmap.get(accno2);
			if(bb1==null) {
				throw new WalletException("Invalid Account Number");
			}
			sal = bb1.getBalance();
			System.out.println("\nInitial balance in :"+accno2+" is: "+sal);
			sal+=input;
			bb1.setBalance(sal);
			if(bb1.getTransactions()==null) {
				bb1.setTransactions("\nFund Transfer: From Account Number: "+accno+" Amount: "+input);
			}
			else
			{
				app="\nFund Transfer: From Account Number: "+accno+"Amount: "+input;
				sum=bb1.getTransactions()+app;
				bb1.setTransactions(sum);
			}
			bankmap.put(accno2, bb1);
			System.out.println("New balance in :"+accno2+" is: "+bb1.getBalance());
			System.out.println();
			return true;
		} catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
	}

	@Override
	public String printTransaction(int accno) throws WalletException {
		
		Bank bb = new Bank();
		String str="No Transactions!";
		try {
			bb = bankmap.get(accno);
			if(bb.getTransactions()==null)
			{
				return str;
			}
			else
			{
				return bb.getTransactions();
			}
		} catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
	}
}
