package com.mywallet.dao;

import com.mywallet.exception.WalletException;

public interface IWalletDao {

	int createAccount(String uname,String upass) throws WalletException;
	boolean login(int accno,String upass) throws WalletException;
	float getBalance(int accno) throws WalletException;
	float depositAcc(int accno,float input) throws WalletException;
	float withdrawAcc(int accno,float input) throws WalletException;
	boolean transferAcc(int accno,int accno2,float input) throws WalletException;
	String printTransaction(int accno) throws WalletException;
	
}
