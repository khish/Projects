package com.mywallet.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.mywallet.bean.Customer;
import com.mywallet.bean.Transfer;
import com.mywallet.exception.WalletException;
import com.mywallet.util.DBConnection;


public class WalletDao implements IWalletDao{


	Logger logger = Logger.getRootLogger();
	int transid=0;
	
	public WalletDao() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	
	@Override
	public int createAccount(Customer cust) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		
		PreparedStatement prepareStatement = null;
		
		int queryResult=0;
		ResultSet resultSet;
		try {
			prepareStatement=connection.prepareStatement(QueryMapper.INSERT_CUSTOMER);
			
			prepareStatement.setString(1, cust.getUserName());
			prepareStatement.setString(2, cust.getMobile());
			prepareStatement.setString(3, cust.getEmail());
			prepareStatement.setString(4, cust.getAddress());
			prepareStatement.setDouble(5, cust.getBalance());
			prepareStatement.setInt(6, cust.getPin());
			
			queryResult=prepareStatement.executeUpdate();
			prepareStatement = connection.prepareStatement(QueryMapper.ACCOUNTNO_SEQUENCE);
			resultSet=prepareStatement.executeQuery();

			if(resultSet.next())
			{
				queryResult=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting employee details failed ");

			}
			else
			{
				logger.info("Employee details added successfully:");
				return queryResult;
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new WalletException("Technical problem occured refer log");
			
		}
		finally {
			try {
				prepareStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new WalletException("Error in closing DB connection");
			}			
		}
	}

	@Override
	public float showBalance(int accNumber) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement prepareStatement = null;
		ResultSet rs = null;
		try {
			prepareStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			prepareStatement.setInt(1, accNumber);
			rs = prepareStatement.executeQuery();
			rs.next();
			float result = rs.getFloat("balance");
			return result;
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new WalletException("Technical problem occured refer log");
		}
		finally {
			try {
				prepareStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new WalletException("Error in closing DB connection");
			}			
		}
	}

	@Override
	public boolean deposit(int num, float amount) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement prepareStatement = null;
		PreparedStatement prepareStatement1=null;
		ResultSet resultSet=null,resultSet2=null;
		int queryResult=0,queryresult1=0;
		try {
			prepareStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
			prepareStatement.setFloat(1, amount);
			prepareStatement.setLong(2, num);
			queryResult = prepareStatement.executeUpdate();
			prepareStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			prepareStatement.setInt(1,num);
			resultSet=prepareStatement.executeQuery();

			if(resultSet.next())
			{
				double balance= resultSet.getDouble("Balance");
				prepareStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
				prepareStatement1.setString(1,"deposit");
				prepareStatement1.setDouble(2,amount);
				prepareStatement1.setLong(4,num);
				PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
				resultSet2=Date.executeQuery();
				if(resultSet2.next())
				{
					Date date=resultSet2.getDate(1);
					prepareStatement1.setDate(3,date);
					
				}
				queryresult1=prepareStatement1.executeUpdate();
				prepareStatement = connection.prepareStatement(QueryMapper.transfer_query_sequence);
				resultSet=prepareStatement.executeQuery();

				if(resultSet.next())
				{
					transid=resultSet.getInt(1);
							
				}
			}
			else
			{
				throw new WalletException("Enter correct account number and pin");
			}
			return true;			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new WalletException("Technical problem occured refer log");
		}
		finally {
			try {
				prepareStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new WalletException("Error in closing DB connection");
			}			
		}
	}

	@Override
	public boolean withdraw(int num, float amount) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet=null,resultSet2=null;
		int queryresult=0;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			preparedStatement.setInt(1,num);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
			float balance1= resultSet.getFloat("Balance");
			if(balance1<amount)
					throw new WalletException("insufficient balance in your account");
			else
			{	
				preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
				preparedStatement.setFloat(1, amount);
				preparedStatement.setInt(2, num);
				queryresult = preparedStatement.executeUpdate();
				preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
				preparedStatement.setInt(1,num);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					float balance= resultSet.getFloat("Balance");
					preparedStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
					preparedStatement1.setString(1,"withdraw");
					preparedStatement1.setFloat(2,amount);
					preparedStatement1.setInt(4,num);
					PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
					resultSet2=Date.executeQuery();
					if(resultSet2.next())
					{
						Date date=resultSet2.getDate(1);
						preparedStatement1.setDate(3,date);
						
					}
					queryresult=preparedStatement1.executeUpdate();
					preparedStatement = connection.prepareStatement(QueryMapper.transfer_query_sequence);
					resultSet=preparedStatement.executeQuery();

					if(resultSet.next())
					{
						transid= resultSet.getInt(1);
								
					}
				}else
					throw new WalletException("invalid details");
			}
			}else
				throw new WalletException("invalid details");
			return true;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new WalletException("Technical problem occured refer log");
		}
		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new WalletException("Error in closing DB connection");
			}			
		}
	}

	@Override
	public boolean fundTransfer(int num, int num1, float amount) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		PreparedStatement preparedStatement1=null;	
		ResultSet resultSet2 = null;
		int queryResult=0;
				if(amount<=0)
					throw new WalletException("for fund to be transfered fund must be greater than 0");
				else
				{
				try
				{
					
					preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
					preparedStatement.setInt(1,num1);
					resultSet=preparedStatement.executeQuery();
					if(resultSet.next())
					{
					double balance1= resultSet.getDouble("Balance");
					if(balance1<amount)
							throw new WalletException("Low balance for fundtranfer");
					
					else 
						{
						
						preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
						preparedStatement.setFloat(1, amount);
						preparedStatement.setInt(2, num);
						queryResult = preparedStatement.executeUpdate();
						
						preparedStatement1=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
						preparedStatement1.setFloat(1, amount);
						preparedStatement1.setInt(2, num1);
						queryResult = preparedStatement1.executeUpdate();
						
						preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
						preparedStatement.setInt(1,num1);
						resultSet=preparedStatement.executeQuery();
						if(resultSet.next())
						{
						float balance2= resultSet.getFloat("Balance");
						preparedStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
						preparedStatement1.setString(1,"fundtransfer(DB)");
						preparedStatement1.setFloat(2,amount);
						preparedStatement1.setInt(4,num1);
						PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
						resultSet2=Date.executeQuery();
						if(resultSet2.next())
						{
							Date date=resultSet2.getDate(1);
							preparedStatement1.setDate(3,date);
							
						}
						queryResult=preparedStatement1.executeUpdate();
						preparedStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
						preparedStatement1.setString(1,"fundtransfer(cr)");
						preparedStatement1.setFloat(2,amount);
						preparedStatement1.setInt(4,num);
						PreparedStatement date1=connection.prepareStatement(QueryMapper.date_query);
						resultSet2=date1.executeQuery();
						if(resultSet2.next())
						{
							Date d=resultSet2.getDate(1);
							preparedStatement1.setDate(3,d);
						}
						queryResult=preparedStatement1.executeUpdate();
						preparedStatement = connection.prepareStatement(QueryMapper.transfer_query_sequence);
						resultSet=preparedStatement.executeQuery();

						if(resultSet.next())
						{
							transid= resultSet.getInt(1);
									
						}
						return true;
						}else
							throw new WalletException("invalid account detailsdetails");
					}
					}else
						throw new WalletException("invalid details");
				}
					catch(SQLException sqlException)
				{
				logger.error(sqlException.getMessage());
				sqlException.printStackTrace();
				throw new WalletException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new WalletException("Error in closing db connection");	
				}
			}
		}		
	}
	
	@Override
	public boolean printtransaction(int accountno) throws WalletException {
		Transfer t=new Transfer();
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.transfer_query2);
			preparedStatement.setLong(1,accountno);	
			resultSet=preparedStatement.executeQuery();
						while(resultSet.next()) {
							t.setTransid(resultSet.getInt("transid"));
							t.setAccountno(resultSet.getLong("accountno"));
							t.setAmount(resultSet.getDouble("amount"));
							t.setTransfertype(resultSet.getString("transfertype"));
							t.setTransDate(resultSet.getDate("transDate"));
							System.out.println(t);
			}
		}catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}return false;
}

	@Override
	public boolean login(int acc, int pass) throws WalletException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement prepareStatement = null;
		ResultSet rs = null;
		int result=0;
		try {
			prepareStatement=connection.prepareStatement(QueryMapper.GET_PIN_CUSTOMER);
			prepareStatement.setInt(1, acc);
			rs = prepareStatement.executeQuery();
			rs.next();
			result = rs.getInt("pin");
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new WalletException("Technical problem occured refer log");
		}
		finally {
			try {
				prepareStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new WalletException("Error in closing DB connection");
			}			
		}
		try {
			if(result!=pass) {
				throw new WalletException("Incorrect Password!");
			}
			return true;
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
	}

}
