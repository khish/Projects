package com.mywallet.db;

import java.util.HashMap;

import com.mywallet.bean.Bank;

public class WalletDB {

	public static HashMap<Integer, Bank> bankmap = new HashMap<Integer, Bank>();
	
	static {
		bankmap.put(1001, new Bank(1001, "Khishore", "khishore", 50000.0f,null));
		bankmap.put(1002, new Bank(1002, "Jake", "jake", 90000.0f,null));
		bankmap.put(1003, new Bank(1003, "July", "july", 50000.0f,null));
	}
	
	public static HashMap<Integer, Bank> getAccountMap(){
		return bankmap;
	}
	
}
