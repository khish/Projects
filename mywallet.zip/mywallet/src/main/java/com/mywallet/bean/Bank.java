package com.mywallet.bean;

public class Bank {

	private int AccNo;
	private String UserName;
	private String Passcode;
	private Float Balance;
	private String Transactions;
	
	public Bank() {
		AccNo = 0;
		UserName = null;
		Passcode = null;
		Balance = 0.0f;
		Transactions = null;
	}
	
	public Bank(int accNo, String userName, String passcode, Float balance, String transactions) {
		super();
		AccNo = accNo;
		UserName = userName;
		Passcode = passcode;
		Balance = balance;
		Transactions = transactions;
	}

	public int getAccNo() {
		return AccNo;
	}


	public void setAccNo(int accNo) {
		AccNo = accNo;
	}


	public String getUserName() {
		return UserName;
	}


	public void setUserName(String userName) {
		UserName = userName;
	}


	public String getPasscode() {
		return Passcode;
	}


	public void setPasscode(String passcode) {
		Passcode = passcode;
	}


	public Float getBalance() {
		return Balance;
	}


	public void setBalance(Float balance) {
		Balance = balance;
	}

	public String getTransactions() {
		return Transactions;
	}

	public void setTransactions(String transactions) {
		Transactions = transactions;
	}
	
	@Override
	public String toString() {
		return "Bank [AccNo=" + AccNo + ", UserName=" + UserName + ", Passcode=" + Passcode + ", Balance=" + Balance
				+ ", Transactions=" + Transactions + "]";
	}
	
}
