package org.cap.demo;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionDemo {
	
	private List<String> names;
	private List<Address> addresses;
	private Set<String> Fruits;
	private Set<Address> addresses2;
	private Map<Integer, String> map;
	private Properties myprop;
	
	public List<String> getNames() {
		return names;
	}
	public void setNames(List<String> names) {
		this.names = names;
	}
	public List<Address> getAddresses() {
		return addresses;
	}
	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	public Set<String> getFruits() {
		return Fruits;
	}
	public void setFruits(Set<String> fruits) {
		Fruits = fruits;
	}
	public Set<Address> getAddresses2() {
		return addresses2;
	}
	public void setAddresses2(Set<Address> addresses2) {
		this.addresses2 = addresses2;
	}
	public Map<Integer, String> getMap() {
		return map;
	}
	public void setMap(Map<Integer, String> map) {
		this.map = map;
	}
	public Properties getMyprop() {
		return myprop;
	}
	public void setMyprop(Properties myprop) {
		this.myprop = myprop;
	}
	
}
