package org.cap.demo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("myBeans.xml");
		
		CollectionDemo demo = (CollectionDemo) context.getBean("collDemo");
		System.out.println(demo.getNames());
		System.out.println(demo.getFruits());
		System.out.println(demo.getAddresses());
		System.out.println(demo.getAddresses2());
		System.out.println(demo.getMap());
		System.out.println(demo.getMyprop());
	}

}
