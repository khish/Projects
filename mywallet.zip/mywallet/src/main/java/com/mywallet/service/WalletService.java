package com.mywallet.service;

import com.mywallet.dao.IWalletDao;
import com.mywallet.dao.WalletDao;
import com.mywallet.exception.WalletException;

public class WalletService implements IWalletService {

	IWalletDao wd = new WalletDao();
	
	
	public boolean validateName(String name) throws WalletException {
		try {
			if((name==null)||(name.equals(null))) {
				throw new WalletException("Name cannot be empty");	
			}
			else
			{
				if(!name.matches("[A-Z][a-z]{2,}")) {
					throw new WalletException("Name should start with capital letters and should contain minimum 3 characters!");
				}
				return true;
			}			
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
	}
	
	@Override
	public int createAccount(String uname, String upass) throws WalletException {
		try {
			if(validateName(uname))
			{
				return wd.createAccount(uname,upass);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		return 0;
	}

	@Override
	public boolean login(int accno, String upass) throws WalletException {
		// TODO Auto-generated method stub
		return wd.login(accno, upass);
	}

	@Override
	public float getBalance(int accno) throws WalletException {
		// TODO Auto-generated method stub
		return wd.getBalance(accno);
	}

	@Override
	public float depositAcc(int accno, float input) throws WalletException {
		// TODO Auto-generated method stub
		return wd.depositAcc(accno,input);
	}

	@Override
	public float withdrawAcc(int accno, float input) throws WalletException {
		// TODO Auto-generated method stub
		return wd.withdrawAcc(accno,input);
	}

	@Override
	public boolean transferAcc(int accno, int accno2, float input) throws WalletException {
		// TODO Auto-generated method stub
		return wd.transferAcc(accno,accno2,input);
	}

	@Override
	public String printTransaction(int accno) throws WalletException {
		// TODO Auto-generated method stub
		return wd.printTransaction(accno);
	}


}
