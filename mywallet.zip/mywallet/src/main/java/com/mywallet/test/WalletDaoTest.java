package com.mywallet.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.mywallet.exception.WalletException;
import com.mywallet.service.IWalletService;
import com.mywallet.service.WalletService;

public class WalletDaoTest {
	
	IWalletService ws;

	@Before
	public void setup() {
		ws = new WalletService();
	}
	
	@After
	public void teardown() {
		ws = null;
	}
	
	@Test
	public void testCreateAccount() {
		try {
			assertEquals(ws.createAccount("Khishy","123"),1004);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testLogin() {
		try {
			assertEquals(ws.login(1002, "jake"), true);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetBalance() {
		try {
			assertEquals(ws.getBalance(1001), 50000, 0.0);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testDepositAcc() {
		try {
			assertEquals(ws.depositAcc(1002, 2000),92000, 0.0);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testWithdrawAcc() {
		try {
			assertEquals(ws.withdrawAcc(1003, 2000),48000, 0.0);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testTransferAcc() {
		try {
			assertEquals(ws.transferAcc(1001, 1002, 0),true);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testPrintTransaction() {
		try {
			assertEquals(ws.printTransaction(1001),"No Transactions!");
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
